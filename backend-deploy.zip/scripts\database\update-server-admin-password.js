#!/usr/bin/env node

const { sequelize } = require('../config/database');
const User = require('../models/User')(sequelize);

async function updateServerAdminPassword() {
  try {
    await sequelize.authenticate();
    console.log('✅ 数据库连接成功');

    // 查找 admin 用户 (尝试多个可能的用户名)
    let adminUser = await User.findOne({ where: { username: 'admin' } });
    if (!adminUser) {
      adminUser = await User.findOne({ where: { username: 'nillithzelah' } });
    }
    if (!adminUser) {
      adminUser = await User.findOne({ where: { username: 'wilee' } });
    }

    if (!adminUser) {
      console.log('❌ 未找到 admin 用户');
      return;
    }

    // 新密码
    const newPassword = 'admin123';

    // 设置新密码
    await adminUser.setPassword(newPassword);

    // 保存更改
    await adminUser.save();

    console.log('✅ 服务器 admin 用户密码已成功更新');
    console.log(`新密码: ${newPassword}`);

  } catch (error) {
    console.error('❌ 更新密码失败:', error.message);
  } finally {
    await sequelize.close();
  }
}

if (require.main === module) {
  updateServerAdminPassword();
}